import re
from datetime import date

# skill canónica -> alias que se buscan en el CV
SKILL_ALIASES = {
    "python": ["python"],
    "sql": ["sql", "mysql", "postgresql", "postgres"],
    "excel": ["excel", "hojas de cálculo"],
    "javascript": ["javascript", "js", "typescript"],
    "atencion_cliente": ["atención al cliente", "atencion al cliente", "customer service"],
    "contabilidad": ["contabilidad", "contable", "accounting"],
    "electromecanica": ["electromecánico", "electromecanico", "electromecánica", "electromecanica"],
    "electricidad": ["electricista", "instalaciones eléctricas", "instalaciones electricas"],
    "refrigeracion": ["refrigeración", "refrigeracion", "frigorista", "climatización", "climatizacion"],
}


def extract_text_from_pdf(data: bytes) -> str:
    try:
        from pypdf import PdfReader
    except ImportError:
        raise RuntimeError("Instala pypdf para leer PDF: pip install pypdf")
    import io
    return "\n".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(data)).pages)


def _skills(text: str) -> list[str]:
    low = text.lower()
    found = []
    for skill, aliases in SKILL_ALIASES.items():
        if any(re.search(rf"(?<!\w){re.escape(a)}(?!\w)", low) for a in aliases):
            found.append(skill)
    return found


def _years(text: str) -> float:
    """Suma aproximada de años a partir de rangos tipo '2019 - 2022' o '2020 - actualidad'."""
    total, now = 0.0, date.today().year
    for a, b in re.findall(r"((?:19|20)\d{2})\s*[-–a]\s*((?:19|20)\d{2}|actualidad|presente|actual)", text.lower()):
        end = now if not b.isdigit() else int(b)
        if end >= int(a):
            total += end - int(a)
    return round(min(total, 45), 1)


def parse_cv(text: str) -> dict:
    years = _years(text)
    level = "senior" if years > 5 else "mid" if years >= 2 else "junior"
    return {"skills": _skills(text), "years_experience": years, "level": level}
