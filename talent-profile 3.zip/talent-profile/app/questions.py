"""Preguntas de ejemplo (originales). Sustituir por instrumentos validados y con licencia."""

# Big Five: escala 1-5. reverse=True invierte la puntuación.
BIG_FIVE = [
    {"id": "b1", "trait": "extraversion", "reverse": False, "text": "Disfruto conociendo gente nueva."},
    {"id": "b2", "trait": "extraversion", "reverse": True, "text": "Prefiero pasar desapercibido en los grupos."},
    {"id": "b3", "trait": "amabilidad", "reverse": False, "text": "Me preocupo por los problemas de mis compañeros."},
    {"id": "b4", "trait": "amabilidad", "reverse": True, "text": "Me cuesta ponerme en el lugar de los demás."},
    {"id": "b5", "trait": "responsabilidad", "reverse": False, "text": "Termino lo que empiezo, aunque sea tedioso."},
    {"id": "b6", "trait": "responsabilidad", "reverse": True, "text": "A menudo dejo las tareas para el último momento."},
    {"id": "b7", "trait": "estabilidad_emocional", "reverse": False, "text": "Mantengo la calma bajo presión."},
    {"id": "b8", "trait": "estabilidad_emocional", "reverse": True, "text": "Me agobio con facilidad ante los imprevistos."},
    {"id": "b9", "trait": "apertura", "reverse": False, "text": "Me gusta probar formas nuevas de hacer las cosas."},
    {"id": "b10", "trait": "apertura", "reverse": True, "text": "Prefiero los métodos de siempre a los cambios."},
]

# Competencias: preguntas situacionales, cada opción vale 0-3 puntos.
COMPETENCIES = [
    {"id": "c1", "competency": "trabajo_en_equipo",
     "text": "Un compañero no entrega su parte a tiempo. ¿Qué haces?",
     "options": [("Lo hago yo sin decir nada", 1), ("Hablo con él para entender el motivo y ofrecer ayuda", 3),
                 ("Aviso directamente al jefe", 1), ("Espero a ver qué pasa", 0)]},
    {"id": "c2", "competency": "comunicacion",
     "text": "Debes explicar un cambio complejo a un cliente no técnico. ¿Cómo lo haces?",
     "options": [("Con todo el detalle técnico", 1), ("Con ejemplos sencillos y comprobando que lo entiende", 3),
                 ("Le envío un documento", 1), ("Se lo explico lo más rápido posible", 0)]},
    {"id": "c3", "competency": "resolucion_problemas",
     "text": "Falla un proceso importante y no hay instrucciones. ¿Qué haces primero?",
     "options": [("Pruebo cambios al azar", 0), ("Identifico la causa, pruebo hipótesis y documento", 3),
                 ("Espero a que alguien lo resuelva", 0), ("Busco a quién culpar", 0)]},
    {"id": "c4", "competency": "organizacion",
     "text": "Tienes cinco tareas urgentes a la vez. ¿Cómo procedes?",
     "options": [("Empiezo por la más fácil", 1), ("Priorizo por impacto y plazo y comunico lo que no llegará", 3),
                 ("Hago un poco de cada una", 1), ("Trabajo más horas sin priorizar", 0)]},
]
