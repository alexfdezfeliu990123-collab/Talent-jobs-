import uuid
from fastapi import FastAPI, HTTPException, UploadFile
from pydantic import BaseModel
from .questions import BIG_FIVE, COMPETENCIES
from .scoring import (score_big_five, score_competencies, build_cv_questions, score_cv_answers,
                      capability_percent, match_role, build_role_questions, score_role_answers)
from .role_bank import ROLE_BANK, TRANSFERABLE
from .cv_parser import parse_cv, extract_text_from_pdf

app = FastAPI(title="Talent Profile API")
DB: dict[str, dict] = {}  # En producción: PostgreSQL

DISCLAIMER = ("Informe orientativo de conocimientos, competencias y rasgos de personalidad. "
              "No es un diagnóstico clínico ni evalúa salud mental. Debe complementarse con entrevista.")


def get(cid: str) -> dict:
    if cid not in DB:
        raise HTTPException(404, "No existe")
    return DB[cid]


class CandidateIn(BaseModel):
    name: str
    email: str
    consent_data_processing: bool


class CVIn(BaseModel):
    cv_text: str


class AnswersIn(BaseModel):
    big_five: dict[str, int] = {}
    competencies: dict[str, int] = {}


class CVAnswersIn(BaseModel):
    answers: dict[str, int]


class TargetRoleIn(BaseModel):
    role: str


class RoleAnswersIn(BaseModel):
    choices: dict[str, int] = {}
    open: dict[str, str] = {}  # respuestas escritas a los casos prácticos


class RoleIn(BaseModel):
    required_skills: list[str] = []
    requirements: dict[str, float] = {}  # mínimos de competencias


@app.post("/candidates")
def create_candidate(c: CandidateIn):
    if not c.consent_data_processing:
        raise HTTPException(400, "Se requiere consentimiento explícito.")
    cid = str(uuid.uuid4())
    DB[cid] = {"name": c.name, "email": c.email, "cv": None, "cv_questions": [], "cv_check": None, "target_role": None, "role_check": None,
               "results": None, "shared": False}
    return {"candidate_id": cid}


def _store_cv(cand: dict, text: str):
    cand["cv"] = parse_cv(text)
    cand["cv_questions"] = build_cv_questions(cand["cv"])
    return cand["cv"]


@app.post("/candidates/{cid}/cv")
def upload_cv_text(cid: str, body: CVIn):
    return _store_cv(get(cid), body.cv_text)


@app.post("/candidates/{cid}/cv-file")
async def upload_cv_pdf(cid: str, file: UploadFile):
    try:
        text = extract_text_from_pdf(await file.read())
    except RuntimeError as e:
        raise HTTPException(500, str(e))
    return _store_cv(get(cid), text)


def role_fit(cand: dict) -> dict:
    """Si el CV no incluye el puesto buscado, NO se descarta: se marca perfil distinto y se evalúa con la prueba del puesto."""
    role, cv = cand["target_role"], cand["cv"]
    if not role or not cv:
        return {"perfil_distinto": None, "habilidades_transferibles": []}
    mismatch = role not in cv["skills"]
    transferable = [s for s in TRANSFERABLE.get(role, []) if s in cv["skills"]]
    return {"perfil_distinto": mismatch, "habilidades_transferibles": transferable,
            "mensaje": ("Perfil distinto al puesto: no se descarta. Demuestra tus conocimientos en la prueba del puesto."
                        if mismatch else "El CV ya incluye experiencia en el puesto.")}


@app.get("/roles")
def roles():
    return {k: v["title"] for k, v in ROLE_BANK.items()}


@app.post("/candidates/{cid}/target-role")
def set_target_role(cid: str, body: TargetRoleIn):
    cand = get(cid)
    if body.role not in ROLE_BANK:
        raise HTTPException(400, f"Puesto no disponible. Opciones: {list(ROLE_BANK)}")
    cand["target_role"] = body.role
    return role_fit(cand)


@app.get("/candidates/{cid}/role-questions")
def role_questions(cid: str):
    cand = get(cid)
    if not cand["target_role"]:
        raise HTTPException(400, "Primero indica el puesto objetivo.")
    return build_role_questions(cand["target_role"])


@app.post("/candidates/{cid}/role-answers")
def role_answers(cid: str, body: RoleAnswersIn):
    cand = get(cid)
    if not cand["target_role"]:
        raise HTTPException(400, "Primero indica el puesto objetivo.")
    cand["role_check"] = score_role_answers(cand["target_role"], body.choices, body.open)
    return cand["role_check"]


@app.get("/tests")
def get_tests():
    return {"big_five": [{k: q[k] for k in ("id", "text")} for q in BIG_FIVE],
            "competencies": [{"id": q["id"], "text": q["text"], "options": [o[0] for o in q["options"]]}
                             for q in COMPETENCIES]}


@app.get("/candidates/{cid}/cv-questions")
def cv_questions(cid: str):
    cand = get(cid)
    if not cand["cv"]:
        raise HTTPException(400, "Primero sube el CV.")
    return [{k: v for k, v in q.items() if k != "_correct"} for q in cand["cv_questions"]]


@app.post("/candidates/{cid}/cv-answers")
def cv_answers(cid: str, body: CVAnswersIn):
    cand = get(cid)
    if not cand["cv_questions"]:
        raise HTTPException(400, "No hay preguntas generadas desde el CV.")
    cand["cv_check"] = score_cv_answers(cand["cv_questions"], body.answers)
    return cand["cv_check"]


@app.post("/candidates/{cid}/answers")
def submit(cid: str, a: AnswersIn):
    cand = get(cid)
    try:
        cand["results"] = {"personalidad": score_big_five(a.big_five),
                           "competencias": score_competencies(a.competencies), "aviso": DISCLAIMER}
    except ValueError as e:
        raise HTTPException(400, str(e))
    return cand["results"]


@app.post("/candidates/{cid}/share")
def share(cid: str, allow: bool = True):
    get(cid)["shared"] = allow
    return {"shared": allow}


@app.post("/company/candidates/{cid}/evaluate")
def company_evaluate(cid: str, role: RoleIn):
    cand = get(cid)
    if not cand["shared"]:
        raise HTTPException(403, "El candidato no ha compartido su informe.")
    comp = cand["results"]["competencias"] if cand["results"] else None
    fit = role_fit(cand)
    out = {"candidate": cand["name"], "cv_detectado": cand["cv"], "aviso": DISCLAIMER,
           "puesto_objetivo": cand["target_role"], **fit,
           "prueba_del_puesto": cand["role_check"],
           "capacitacion": capability_percent(cand["cv_check"], comp, cand["role_check"],
                                              bool(fit["perfil_distinto"]), role.required_skills)}
    if comp and role.requirements:
        out["encaje_competencias"] = match_role(comp, role.requirements)
    if cand["results"]:
        out["personalidad"] = cand["results"]["personalidad"]
    return out
