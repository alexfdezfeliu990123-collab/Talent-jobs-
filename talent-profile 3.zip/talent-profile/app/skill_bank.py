"""Banco de preguntas de verificación por skill. (texto, [opciones], índice_correcto, nivel)
Ejemplo mínimo: ampliar y validar con expertos de cada área."""
BANK = {
    "python": [
        ("¿Qué devuelve len([1, 2, 3])?", ["2", "3", "4", "Error"], 1, "basic"),
        ("¿Qué estructura NO admite elementos duplicados?", ["list", "tuple", "set", "str"], 2, "basic"),
        ("¿Para qué sirve un decorador?", ["Comentar código", "Modificar el comportamiento de una función sin cambiar su código",
                                          "Declarar variables globales", "Importar módulos"], 1, "advanced"),
    ],
    "sql": [
        ("¿Qué cláusula filtra filas tras agrupar con GROUP BY?", ["WHERE", "HAVING", "ORDER BY", "LIMIT"], 1, "basic"),
        ("¿Qué hace un LEFT JOIN?", ["Solo filas coincidentes", "Todas las filas de la tabla izquierda y las coincidentes de la derecha",
                                     "Todas las de la derecha", "Producto cartesiano"], 1, "basic"),
        ("¿Para qué sirve un índice?", ["Cifrar datos", "Acelerar las consultas de búsqueda", "Borrar duplicados", "Crear copias de seguridad"], 1, "advanced"),
    ],
    "excel": [
        ("¿Qué función busca un valor en la primera columna de una tabla?", ["SUMAR", "BUSCARV", "CONTAR", "SI"], 1, "basic"),
        ("¿Para qué sirve una tabla dinámica?", ["Dar formato", "Resumir y analizar grandes conjuntos de datos", "Proteger el archivo", "Imprimir"], 1, "advanced"),
    ],
    "javascript": [
        ("¿Qué diferencia a 'const' de 'let'?", ["Ninguna", "const no permite reasignar la variable", "const es global", "let es obsoleto"], 1, "basic"),
        ("¿Qué devuelve una función async?", ["undefined", "Una Promise", "Un array", "Un string"], 1, "advanced"),
    ],
    "atencion_cliente": [
        ("Un cliente enfadado reclama. ¿Qué haces primero?", ["Discutir", "Escuchar con empatía y confirmar el problema", "Derivarlo sin hablar", "Ignorarlo"], 1, "basic"),
        ("¿Qué indica un buen seguimiento postventa?", ["Cerrar el caso rápido", "Comprobar que el problema quedó resuelto", "Evitar más contacto", "Enviar publicidad"], 1, "advanced"),
    ],
    "contabilidad": [
        ("En contabilidad, el activo = ", ["Pasivo + Patrimonio neto", "Ingresos - gastos", "Pasivo - Patrimonio neto", "Ventas"], 0, "basic"),
        ("¿Qué recoge el balance de situación?", ["Flujo de caja del mes", "Activos, pasivos y patrimonio en una fecha", "Solo ingresos", "Nóminas"], 1, "advanced"),
    ],
    "electromecanica": [
        ("¿Qué mide un polímetro (multímetro)?", ["Solo la presión", "Tensión, corriente y resistencia", "Solo la temperatura", "El par de apriete"], 1, "basic"),
        ("¿Para qué sirve un contactor?", ["Medir corriente", "Conectar y cortar a distancia la alimentación de una carga", "Reducir la tensión", "Filtrar armónicos"], 1, "basic"),
        ("Un motor trifásico arranca pero se calienta mucho y consume de más. ¿Qué es lo primero a revisar?", ["Cambiar el motor", "Tensión de las fases, desequilibrio y estado de rodamientos", "Subir la protección", "Nada, es normal"], 1, "advanced"),
    ],
}
