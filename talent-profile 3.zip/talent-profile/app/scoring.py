from collections import defaultdict
from .questions import BIG_FIVE, COMPETENCIES
import unicodedata
from .skill_bank import BANK
from .role_bank import ROLE_BANK


def score_big_five(answers: dict[str, int]) -> dict[str, float]:
    totals, counts = defaultdict(float), defaultdict(int)
    for q in BIG_FIVE:
        if q["id"] not in answers:
            continue
        v = answers[q["id"]]
        if not 1 <= v <= 5:
            raise ValueError(f"Respuesta fuera de rango en {q['id']}")
        if q["reverse"]:
            v = 6 - v
        totals[q["trait"]] += v
        counts[q["trait"]] += 1
    return {t: round((totals[t] / counts[t] - 1) / 4 * 100, 1) for t in totals}


def score_competencies(answers: dict[str, int]) -> dict[str, float]:
    totals, maxes = defaultdict(float), defaultdict(float)
    for q in COMPETENCIES:
        if q["id"] not in answers:
            continue
        idx = answers[q["id"]]
        if not 0 <= idx < len(q["options"]):
            raise ValueError(f"Opción inválida en {q['id']}")
        totals[q["competency"]] += q["options"][idx][1]
        maxes[q["competency"]] += max(o[1] for o in q["options"])
    return {c: round(totals[c] / maxes[c] * 100, 1) for c in totals}


def build_cv_questions(parsed_cv: dict) -> list[dict]:
    """Genera preguntas según las skills del CV y el nivel (junior solo básicas)."""
    levels = {"basic"} if parsed_cv["level"] == "junior" else {"basic", "advanced"}
    out = []
    for skill in parsed_cv["skills"]:
        for i, (text, opts, correct, lvl) in enumerate(BANK.get(skill, [])):
            if lvl in levels:
                out.append({"id": f"{skill}:{i}", "skill": skill, "text": text, "options": opts, "_correct": correct})
    return out


def score_cv_answers(questions: list[dict], answers: dict[str, int]) -> dict:
    per = defaultdict(lambda: [0, 0])  # skill -> [aciertos, total]
    for q in questions:
        per[q["skill"]][1] += 1
        if answers.get(q["id"]) == q["_correct"]:
            per[q["skill"]][0] += 1
    by_skill = {s: round(a / t * 100, 1) for s, (a, t) in per.items()}
    confirmed = [s for s, p in by_skill.items() if p >= 50]
    return {"by_skill": by_skill, "confirmed": confirmed,
            "not_confirmed": [s for s in by_skill if s not in confirmed],
            "overall": round(sum(a for a, _ in per.values()) / max(1, sum(t for _, t in per.values())) * 100, 1)}


def _norm(t: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn")


def build_role_questions(role: str) -> dict:
    data = ROLE_BANK[role]
    return {"role": role, "title": data["title"],
            "multiple_choice": [{"id": f"mc{i}", "text": q[0], "options": q[1]} for i, q in enumerate(data["mc"])],
            "scenarios": [{"id": sc["id"], "text": sc["text"]} for sc in data["scenarios"]]}


def score_open_answer(text: str, criteria: list[dict]) -> dict:
    n = _norm(text)
    covered = [c["label"] for c in criteria if any(_norm(k) in n for k in c["keywords"])]
    return {"percent": round(len(covered) / len(criteria) * 100, 1), "cubierto": covered,
            "no_mencionado": [c["label"] for c in criteria if c["label"] not in covered]}


def score_role_answers(role: str, choices: dict[str, int], open_answers: dict[str, str]) -> dict:
    data = ROLE_BANK[role]
    ok = sum(1 for i, q in enumerate(data["mc"]) if choices.get(f"mc{i}") == q[2])
    mc_pct = round(ok / len(data["mc"]) * 100, 1)
    detail = {sc["id"]: score_open_answer(open_answers.get(sc["id"], ""), sc["criteria"]) for sc in data["scenarios"]
              if open_answers.get(sc["id"])}
    if detail:
        open_pct = round(sum(d["percent"] for d in detail.values()) / len(detail), 1)
        overall = round(0.5 * mc_pct + 0.5 * open_pct, 1)
    else:
        open_pct, overall = None, mc_pct
    return {"role": role, "overall": overall, "multiple_choice": mc_pct, "casos_practicos": open_pct,
            "detalle_casos": detail, "revision_humana_recomendada": True}


def capability_percent(cv_check: dict | None, competencies: dict[str, float] | None,
                       role_check: dict | None = None, mismatch: bool = False,
                       required_skills: list[str] | None = None) -> dict:
    """Sin prueba de puesto: 70% CV + 30% competencias.
    Con prueba de puesto: 30% puesto + 40% CV + 30% competencias; si el perfil es distinto
    al puesto, pesa más lo que demuestra (50% puesto + 20% CV + 30% competencias)."""
    comp = round(sum(competencies.values()) / len(competencies), 1) if competencies else None
    if role_check:
        weights = {"role": 0.5 if mismatch else 0.3, "cv": 0.2 if mismatch else 0.4, "comp": 0.3}
    else:
        weights = {"role": 0, "cv": 0.7, "comp": 0.3}
    values = {"role": role_check["overall"] if role_check else None,
              "cv": cv_check["overall"] if cv_check else None, "comp": comp}
    avail = {k: w for k, w in weights.items() if w and values[k] is not None}
    if not avail:
        return {"capability_percent": None, "motivo": "Faltan pruebas por completar."}
    pct = sum(values[k] * w for k, w in avail.items()) / sum(avail.values())
    confirmed = list(cv_check["confirmed"]) if cv_check else []
    if role_check and role_check["overall"] >= 50:
        confirmed.append(role_check["role"])
    missing = [s for s in (required_skills or []) if s not in confirmed]
    if required_skills:
        pct *= (len(required_skills) - len(missing)) / len(required_skills) * 0.3 + 0.7
    return {"capability_percent": round(pct, 1), "skills_confirmadas": confirmed,
            "skills_no_confirmadas": cv_check["not_confirmed"] if cv_check else [],
            "skills_requeridas_sin_confirmar": missing, "media_competencias": comp,
            "componentes_usados": sorted(avail)}


def match_role(competencies: dict[str, float], requirements: dict[str, float]) -> dict:
    gaps = {c: round(m - competencies.get(c, 0), 1) for c, m in requirements.items() if competencies.get(c, 0) < m}
    met = len(requirements) - len(gaps)
    return {"match_percent": round(met / len(requirements) * 100, 1) if requirements else 0.0, "gaps": gaps}
