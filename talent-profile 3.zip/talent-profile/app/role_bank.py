"""Pruebas por puesto objetivo, para quien cambia de perfil.
mc: (texto, opciones, índice_correcto). scenarios: preguntas abiertas de fallas, corregidas por criterios.
Ejemplo mínimo: ampliar y validar con técnicos del sector."""

# puesto -> skills del CV que se consideran transferibles
TRANSFERABLE = {
    "refrigeracion": ["electromecanica", "electricidad"],
}

ROLE_BANK = {
    "refrigeracion": {
        "title": "Técnico en refrigeración",
        "mc": [
            ("¿Qué componente comprime el refrigerante y lo hace circular?",
             ["Evaporador", "Compresor", "Condensador", "Válvula de expansión"], 1),
            ("¿En qué componente absorbe calor el refrigerante del espacio a enfriar?",
             ["Evaporador", "Compresor", "Condensador", "Filtro secador"], 0),
            ("¿Qué mide un juego de manómetros?",
             ["La humedad del aire", "Las presiones de baja y alta del circuito", "El consumo eléctrico", "El caudal de agua"], 1),
            ("¿Qué es el sobrecalentamiento?",
             ["Que el compresor está caliente", "La temperatura del vapor por encima de su temperatura de saturación a la salida del evaporador",
              "Exceso de tensión", "Hielo en el evaporador"], 1),
            ("Antes de abrir un circuito frigorífico, ¿qué es obligatorio?",
             ["Ventear el refrigerante", "Recuperar el refrigerante con un equipo adecuado", "Apagar solo el termostato", "Nada especial"], 1),
        ],
        "scenarios": [
            {"id": "s1",
             "text": "Una cámara frigorífica no baja de temperatura. El compresor funciona pero el evaporador apenas enfría. "
                     "¿Qué revisarías y cómo lo solucionarías?",
             "criteria": [
                 {"label": "Medir presiones con manómetros", "keywords": ["manometro", "presion"]},
                 {"label": "Comprobar fuga o falta de carga", "keywords": ["fuga", "carga", "falta de gas", "poco gas", "refrigerante"]},
                 {"label": "Buscar obstrucciones (filtro, capilar o válvula de expansión)", "keywords": ["filtro", "obstruc", "capilar", "valvula de expansion"]},
                 {"label": "Revisar ventiladores, hielo o desescarche", "keywords": ["ventilador", "hielo", "escarcha", "desescarche", "descongel"]},
             ]},
            {"id": "s2",
             "text": "El compresor se para a los pocos minutos por el protector térmico. ¿Qué causas buscarías y qué harías?",
             "criteria": [
                 {"label": "Revisar condensador sucio o ventilador del condensador", "keywords": ["condensador", "ventilador", "suciedad", "limpi"]},
                 {"label": "Medir parámetros eléctricos", "keywords": ["tension", "voltaje", "amperaje", "amperio", "consumo", "arranque", "rele"]},
                 {"label": "Valorar presión alta o exceso de carga", "keywords": ["presion alta", "sobrecarga", "exceso de gas", "carga"]},
                 {"label": "Aplicar medidas de seguridad", "keywords": ["desconect", "seguridad", "epi", "bloqueo"]},
             ]},
        ],
    },
}
