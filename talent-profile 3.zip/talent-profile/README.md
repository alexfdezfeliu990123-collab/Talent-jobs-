# Talent Profile

API (FastAPI) que evalúa a candidatos a partir de su CV, un test de personalidad (Big Five), un test de
competencias y una prueba del puesto al que aspiran. Pensada para que **quien cambia de perfil no sea descartado**
y pueda demostrar lo que sabe.

## Ejecutar
    pip install -r requirements.txt
    uvicorn app.main:app --reload      # http://localhost:8000/docs
    # o con Docker: docker build -t talent-profile . && docker run -p 8000:8000 talent-profile

## Tests
    pip install -r requirements-dev.txt
    pytest -q

## Flujo
1. `POST /candidates` (requiere consentimiento)
2. `POST /candidates/{id}/cv` (texto) o `/cv-file` (PDF): detecta skills, años y nivel
3. `POST /candidates/{id}/target-role` {"role": "refrigeracion"}: indica `perfil_distinto` y habilidades transferibles
4. `GET /candidates/{id}/cv-questions` -> `POST .../cv-answers`
5. `GET /candidates/{id}/role-questions` -> `POST .../role-answers`: test básico del puesto + casos de fallas
   ("¿qué revisarías y cómo lo solucionarías?"), corregidos por criterios
6. `GET /tests` -> `POST /candidates/{id}/answers`: personalidad y competencias
7. `POST /candidates/{id}/share`: el candidato autoriza a la empresa
8. `POST /company/candidates/{id}/evaluate`: % de capacitación y desglose

## Cómo se calcula la capacitación
- Sin prueba del puesto: 70% CV + 30% competencias.
- Con prueba del puesto: 30% puesto + 40% CV + 30% competencias.
- Si el perfil es distinto al puesto: 50% puesto + 20% CV + 30% competencias (pesa lo que demuestra).
- Si la empresa exige skills no confirmadas, el porcentaje baja.

## Límites importantes
- No evalúa salud mental ni emite veredictos de aptitud psicológica.
- Los casos prácticos se corrigen por palabras clave: sirven de apoyo, **requieren revisión humana**.
- Los bancos de preguntas (`app/skill_bank.py`, `app/role_bank.py`) son ejemplos; hay que ampliarlos y validarlos con expertos.
- Perfiles: usar OAuth de LinkedIn, API oficial de InfoJobs o subida de CV; no scraping.
- Antes de producción: base de datos real, cifrado, autenticación y revisión legal (RGPD, AI Act).

## Añadir un puesto
Añade una entrada en `ROLE_BANK` (`app/role_bank.py`) con preguntas tipo test y casos prácticos con sus criterios.

## Subir a GitHub
    git remote add origin https://github.com/TU_USUARIO/talent-profile.git
    git push -u origin main
