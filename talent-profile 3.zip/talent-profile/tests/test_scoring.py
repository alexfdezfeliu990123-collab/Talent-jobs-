from app.cv_parser import parse_cv
from app.scoring import (score_big_five, build_cv_questions, score_cv_answers, capability_percent,
                         score_role_answers, score_open_answer)
from app.role_bank import ROLE_BANK


def test_big_five_neutral():
    assert set(score_big_five({f"b{i}": 3 for i in range(1, 11)}).values()) == {50.0}


def test_cv_parser_detects_skills_and_level():
    cv = parse_cv("Electromecánico 2015 - 2024. Instalaciones eléctricas.")
    assert "electromecanica" in cv["skills"] and cv["level"] == "senior"


def test_career_change_is_not_discarded():
    cv = parse_cv("Electromecánico 2015 - 2024")
    qs = build_cv_questions(cv)
    chk = score_cv_answers(qs, {q["id"]: q["_correct"] for q in qs})
    role = ROLE_BANK["refrigeracion"]
    choices = {f"mc{i}": q[2] for i, q in enumerate(role["mc"])}
    answer = ("Mediría presiones con manómetros, buscaría una fuga o falta de carga, "
              "revisaría el filtro y el ventilador del evaporador por hielo.")
    rc = score_role_answers("refrigeracion", choices, {"s1": answer})
    assert rc["overall"] == 100.0
    res = capability_percent(chk, {"comunicacion": 70}, rc, mismatch=True, required_skills=["refrigeracion"])
    assert res["capability_percent"] > 70 and res["skills_requeridas_sin_confirmar"] == []


def test_open_answer_accents_and_empty():
    crit = ROLE_BANK["refrigeracion"]["scenarios"][0]["criteria"]
    assert score_open_answer("Manómetros y presión", crit)["percent"] == 25.0
    assert score_open_answer("", crit)["percent"] == 0.0
