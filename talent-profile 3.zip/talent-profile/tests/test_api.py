from fastapi.testclient import TestClient
from app.main import app

c = TestClient(app)


def test_full_flow_career_change():
    cid = c.post("/candidates", json={"name": "Ana", "email": "a@x.com", "consent_data_processing": True}).json()["candidate_id"]
    assert c.post("/candidates", json={"name": "B", "email": "b@x.com", "consent_data_processing": False}).status_code == 400
    c.post(f"/candidates/{cid}/cv", json={"cv_text": "Electromecánico 2015 - 2024"})
    fit = c.post(f"/candidates/{cid}/target-role", json={"role": "refrigeracion"}).json()
    assert fit["perfil_distinto"] is True and "electromecanica" in fit["habilidades_transferibles"]
    q = c.get(f"/candidates/{cid}/role-questions").json()
    assert q["multiple_choice"] and "_correct" not in str(q)
    c.post(f"/candidates/{cid}/role-answers", json={"choices": {"mc0": 1}, "open": {"s1": "Revisaría presión y fuga"}})
    assert c.post(f"/company/candidates/{cid}/evaluate", json={}).status_code == 403
    c.post(f"/candidates/{cid}/share")
    r = c.post(f"/company/candidates/{cid}/evaluate", json={"required_skills": ["refrigeracion"]}).json()
    assert r["perfil_distinto"] is True and r["capacitacion"]["capability_percent"] is not None
